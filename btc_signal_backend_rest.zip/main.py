import requests
import pandas as pd
import numpy as np
from fastapi import FastAPI
from fastapi.responses import JSONResponse
import time

app = FastAPI()

def fetch_candles(symbol="BTCUSDT", interval="1m", limit=100):
    url = f"https://api.binance.com/api/v3/klines"
    params = {
        "symbol": symbol,
        "interval": interval,
        "limit": limit
    }
    response = requests.get(url, params=params)
    data = response.json()
    closes = [float(candle[4]) for candle in data]
    timestamps = [int(candle[0]) for candle in data]
    return pd.Series(closes, index=pd.to_datetime(timestamps, unit='ms'))

def calculate_rsi(prices, period=14):
    delta = prices.diff()
    gain = np.where(delta > 0, delta, 0)
    loss = np.where(delta < 0, -delta, 0)
    avg_gain = pd.Series(gain).rolling(window=period).mean()
    avg_loss = pd.Series(loss).rolling(window=period).mean()
    rs = avg_gain / avg_loss
    rsi = 100 - (100 / (1 + rs))
    return rsi

def calculate_macd(prices, slow=26, fast=12, signal=9):
    exp1 = prices.ewm(span=fast, adjust=False).mean()
    exp2 = prices.ewm(span=slow, adjust=False).mean()
    macd = exp1 - exp2
    signal_line = macd.ewm(span=signal, adjust=False).mean()
    return macd, signal_line

@app.get("/signal")
def get_signal():
    prices = fetch_candles()
    rsi = calculate_rsi(prices).iloc[-1]
    macd, signal_line = calculate_macd(prices)
    macd_val = macd.iloc[-1]
    signal_val = signal_line.iloc[-1]

    signal = None
    if rsi < 30 and macd_val > signal_val:
        signal = "BUY"
    elif rsi > 70 and macd_val < signal_val:
        signal = "SELL"

    return JSONResponse(content={
        "timestamp": int(time.time() * 1000),
        "signal": signal,
        "price": round(prices.iloc[-1], 2),
        "indicators": {
            "rsi": round(rsi, 2),
            "macd": round(macd_val, 2),
            "macd_signal": round(signal_val, 2)
        }
    })